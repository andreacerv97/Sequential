#include <iostream>
#include<fstream>
#include<random>
#include<cmath>
#include<iomanip>   //setprecision
#include"fn_aos.hpp"

// AOS

int main(int argc, char *argv[]){

    // status stands for checking status

    std::cout << "sim-aos invoked with "<<argc - 1<<" parameters\n";
    std::cout << "Arguments:\n";

    // first we must check if the number of parameters read is exactly 6
    if(argc != 6){

        // if the number of parameters is incorrect we print the given arguments and then return -1
        if(argc == 1){
            std::cout<<"\tnum_objects: ?\n";
            std::cout<<"\tnum_iterations: ?\n";
            std::cout<<"\tseed: ?\n";
            std::cout<<"\tsize_enclosure: ?\n";
            std::cout<<"\ttime_step: ?\n";
        }
        else if(argc == 2)
        {
            std::cout<<"\tnum_objects: "<<argv[1]<<"\n";
            std::cout<<"\tnum_iterations: ?\n";
            std::cout<<"\tseed: ?\n";
            std::cout<<"\tsize_enclosure: ?\n";
            std::cout<<"\ttime_step: ?\n";
        }
        else if(argc == 3)
        {
            std::cout<<"\tnum_objects: "<<argv[1]<<"\n";
            std::cout<<"\tnum_iterations: "<<argv[2]<<"\n";
            std::cout<<"\tseed: ?\n";
            std::cout<<"\tsize_enclosure: ?\n";
            std::cout<<"\ttime_step: ?\n";
        }
        else if(argc == 4)
        {
            std::cout<<"\tnum_objects: "<<argv[1]<<"\n";
            std::cout<<"\tnum_iterations: "<<argv[2]<<"\n";
            std::cout<<"\tseed: "<<argv[3]<<"\n";
            std::cout<<"\tsize_enclosure: ?\n";
            std::cout<<"\ttime_step: ?\n";
        }
        else if(argc == 5)
        {
            std::cout<<"\tnum_objects: "<<argv[1]<<"\n";
            std::cout<<"\tnum_iterations: "<<argv[2]<<"\n";
            std::cout<<"\tseed: "<<argv[3]<<"\n";
            std::cout<<"\tsize_enclosure: "<<argv[4]<<"\n";
            std::cout<<"\ttime_step: ?\n";
        }
        else
        {
            std::cout<<"\tnum_objects: "<<argv[1]<<"\n";
            std::cout<<"\tnum_iterations: "<<argv[2]<<"\n";
            std::cout<<"\tseed: "<<argv[3]<<"\n";
            std::cout<<"\tsize_enclosure: "<<argv[4]<<"\n";
            std::cout<<"\ttime_step: "<<argv[5]<<"\n";
        }
        return -1;
    }

    // when the number of parameters is correct we must check whether they have legal values or not
    // first we must check that num_objects and num_iterations are non-negative integers
    char *end1, *end2, *end3, *end4, *end5; 
    double size_enclosure, time_step;
    long int num_objects, num_iterations, seed;

    num_objects= strtol(argv[1], &end1, 10);
    num_iterations = strtol(argv[2], &end2, 10);
    seed = strtol(argv[3], &end3, 10);
    size_enclosure = strtof(argv[4], &end4);
    time_step = strtof(argv[5], &end5);

    if ((*end1 != '\0')||(*end2 != '\0')||(*end3 != '\0')||(*end4 != 0) ||(*end5 != 0 )) {

        //then if num_objects or num_iterations or the seed or all of them are not an integer, we return -2
        std::cout<<"\tnum_objects: "<<argv[1]<<"\n";
        std::cout<<"\tnum_iterations: "<<argv[2]<<"\n";
        std::cout<<"\tseed: "<<argv[3]<<"\n";
        std::cout<<"\tsize_enclosure: "<<argv[4]<<"\n";
        std::cout<<"\ttime_step: "<<argv[5]<<"\n";

        return -2;
    }

    // now we must check if they are non-negative
    if((num_objects < 0)||(num_iterations<0)||(seed <= 0)||(size_enclosure < 0)||(time_step < 0)) {

        //if one of them has an illegal value, we return -2
        std::cout<<"\tnum_objects: "<<argv[1]<<"\n";
        std::cout<<"\tnum_iterations: "<<argv[2]<<"\n";
        std::cout<<"\tseed: "<<argv[3]<<"\n";
        std::cout<<"\tsize_enclosure: "<<argv[4]<<"\n";
        std::cout<<"\ttime_step: "<<argv[5]<<"\n";

        return -2;
    }

    // we print on screen the arguments

    std::cout<<"\tnum_objects: "<<argv[1]<<"\n";
    std::cout<<"\tnum_iterations: "<<argv[2]<<"\n";
    std::cout<<"\tseed: "<<argv[3]<<"\n";
    std::cout<<"\tsize_enclosure: "<<argv[4]<<"\n";
    std::cout<<"\ttime_step: "<<argv[5]<<"\n";


    //now we must create the random initial positions, we create as many positions as number of objects

    auto *objs= new Objects[num_objects];

    //we compute the random values using the mersenne twister, and the appropriate distributions

    std::mt19937_64 generator(seed);
    std::uniform_real_distribution<> dis(0, size_enclosure);
    std::normal_distribution<> d{1e21, 1e15};

    // we generate the random coordinates and mass for each object
    for(int i = 0; i < num_objects; ++i){
        objs[i].pos.x = dis(generator);
        objs[i].pos.y = dis(generator);
        objs[i].pos.z = dis(generator);
        objs[i].vel.x = 0.000;
        objs[i].vel.y = 0.000;
        objs[i].vel.z = 0.000;
        objs[i].m = d(generator);
        objs[i].flag = 1;
    }

    // we must check that there are no two objects i the same position
    for(int i = 0; i < num_objects; ++i){
        for(int j = i; j < num_objects; ++j ){
            if(j != i){
                if (distance(objs[i], objs[j]) < 1){
                    // if there are collisions at the beginning we must merge the two objects into one
                    objs[i].m += objs[j].m;     // masses are added
                    objs[i].vel.x += objs[j].vel.x;
                    objs[i].vel.y += objs[j].vel.y;
                    objs[i].vel.z += objs[j].vel.z;
                    objs[j].flag = 0;
                }
            }
        }
    }


    // now we write the initial configuration into the file init_conf.txt
    std::ofstream out("myinit_config.txt");
    // first the header line
    out<<std::fixed;
    out<<std::setprecision(3);
    out <<size_enclosure <<" "<< time_step <<" "<< num_objects << "\n";
    // then the information regarding the rest of the objects
    for(int i = 0; i < num_objects; ++i){
        if (objs[i].flag){ // if the value of the flag is 1 (if the object exists)
            out << objs[i].pos.x << " " << objs[i].pos.y << " " << objs[i].pos.z << " " << objs[i].vel.x << " " << objs[i].vel.y << " " << objs[i].vel.z << " " << objs[i].m << "\n";
        }

    }

    out.close(); //close the file





    // first we need to compute the gravitational forces between each object

    //Forces definition to pass to function
    vect **Forces;
    Forces = new vect *[num_objects];
    for (int i=0; i<num_objects;i++) Forces[i]= new vect[num_objects];

    // then comes the simulation part
    for(int i = 0; i < num_iterations; ++i){ //loop as many iterations as the argument

        //gravitation
        grav_it(objs, Forces, num_objects);

        //acceleration, velocity and position
        pos_it(objs, Forces, num_objects,time_step,size_enclosure);

        //collision check
        for(int k = 0; k < num_objects; ++k){
            for(int j = k; j < num_objects; ++j ){
                if(j != k){
                    if ((objs[j].flag==1)&&(objs[k].flag==1)) {
                    if (distance(objs[k], objs[j]) < 1) {
                        // if there are collisions at the beginning we must merge the two objects into one
                        objs[k].m += objs[j].m; // masses must be added
                        objs[j].m = 0;
                        objs[k].vel.x += objs[j].vel.x;
                        objs[k].vel.y += objs[j].vel.y;
                        objs[k].vel.z += objs[j].vel.z;
                        objs[j].flag = 0; //change the flag to 0, the object dissapears
                    }
                    }
                }
            }
        }
    }

    //finally, we print the final configuration after the simulation

    std::ofstream final("myfinal_config.txt");

    final<<std::fixed;
    final<<std::setprecision(3);
    final<<"aos2"<<std::endl;
    final << size_enclosure << " " << time_step  << " " << num_objects << "\n";
    for(int i = 0; i < num_objects; ++i) {
        if (objs[i].flag==1)
        {
            final << objs[i].pos.x << " " << objs[i].pos.y << " " << objs[i].pos.z << " " << objs[i].vel.x << " "
                  << objs[i].vel.y << " " << objs[i].vel.z << " " << objs[i].m << "\n";
        }
    }

    final.close();
 
    return 0;

    //end of the main

}