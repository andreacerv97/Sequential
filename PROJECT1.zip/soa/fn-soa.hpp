#ifndef PROJECT1_FN_SOA_HPP
#define PROJECT1_FN_SOA_HPP

const double G = 6.674e-11;

struct vect{
    double x;
    double y;
    double z;
};

struct Objects{
    std::vector<vect> pos;
    std::vector<vect> vel;
    std::vector<double> m;
    std::vector <int> flag;   // 1 if the object exists, when it is merged into another it goes into 0
};

double distance(double x1, double y1, double z1, double x2, double y2, double z2) {
    double dis = std::sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2) + (z1 - z2) * (z1 - z2));
    return dis;
}
//declarar Forces antes
//meter pointers
//duda coefficient?

void grav_it(Objects &objs, vect **Forces, long int num_objects, double time_step, double size_enclosure) {
    double coefficient;

    for (int i = 0; i < num_objects; ++i) {
        if (objs.flag[i]) {
            Forces[i][i].x = 0;  //Inicialización dentro o fuera de la func?
            Forces[i][i].y = 0;
            Forces[i][i].z = 0;
            for (int j = i; j < num_objects; ++j) {
                if ((j != i) && (objs.flag[j])) {
                    coefficient = (G * objs.m[i] * objs.m[j]) / (pow(sqrt(pow(objs.pos[i].x
                                                                              - objs.pos[j].x, 2) +
                                                                          pow(objs.pos[i].y - objs.pos[j].y, 2) +
                                                                          pow(objs.pos[i].z - objs.pos[j].z, 2)), 3));
                    Forces[i][j].x = coefficient * (objs.pos[j].x - objs.pos[i].x);
                    Forces[j][i].x = -Forces[i][j].x;
                    Forces[i][j].y = coefficient * (objs.pos[j].y - objs.pos[i].y);
                    Forces[j][i].y = -Forces[i][j].y;
                    Forces[i][j].z = coefficient * (objs.pos[j].z - objs.pos[i].z);
                    Forces[j][i].z = -Forces[i][j].z;
                }
            }
        }
    }
            for (int k = 0; k < num_objects; ++k) {
                if (objs.flag[k]) {
            double sumx = 0;    //Inicialización dentro o fuera de la func?
            double sumy = 0;
            double sumz = 0;
                    for (int j = 0; j < num_objects; ++j) {
                        if (objs.flag[j]) {
                            sumx += Forces[k][j].x;
                            sumy += Forces[k][j].y;
                            sumz += Forces[k][j].z;
                        }
                    }
                    objs.vel[k].x = objs.vel[k].x + (sumx / objs.m[k]) * time_step;
                    objs.vel[k].y = objs.vel[k].y + (sumy / objs.m[k]) * time_step;
                    objs.vel[k].z = objs.vel[k].z + (sumz / objs.m[k]) * time_step;
                    objs.pos[k].x = objs.pos[k].x + objs.vel[k].x * time_step;
                    objs.pos[k].y = objs.pos[k].y + objs.vel[k].y * time_step;
                    objs.pos[k].z = objs.pos[k].z + objs.vel[k].z * time_step;

                    if (objs.pos[k].x <= 0) {
                        objs.pos[k].x = 0;
                        objs.vel[k].x = -objs.vel[k].x;
                    }

                    if (objs.pos[k].y <= 0) {
                        objs.pos[k].y = 0;
                        objs.vel[k].y = -objs.vel[k].y;
                    }

                    if (objs.pos[k].z <= 0) {
                        objs.pos[k].z = 0;
                        objs.vel[k].z = -objs.vel[k].z;
                    }

                    if (objs.pos[k].x >= size_enclosure) {
                        objs.pos[k].x = size_enclosure;
                        objs.vel[k].x = -objs.vel[k].x;
                    }

                    if (objs.pos[k].y >= size_enclosure) {
                        objs.pos[k].y = size_enclosure;
                        objs.vel[k].y = -objs.vel[k].y;
                    }

                    if (objs.pos[k].z >= size_enclosure) {
                        objs.pos[k].z = size_enclosure;
                        objs.vel[k].z = -objs.vel[k].z;
                    }

                }
            }
        }



void collisions(long int num_objects,Objects objs) {
    for (int k = 0; k < num_objects; ++k) {
        for (int j = k; j < num_objects; ++j) {
            if (j != k) {
                if ((objs.flag[j] == 1) && (objs.flag[k] == 1)) {
// poner if(distance(i,j) < 1 sumar masas velocidades y cambiar flags
                    if (distance(objs.pos[k].x, objs.pos[k].y, objs.pos[k].z, objs.pos[j].x, objs.pos[j].y,
                                 objs.pos[j].z) < 1) {
// if there are collisions at the beginning we must merge the two objects into one
                        objs.m[k] += objs.m[j];     // masses must be added
                        objs.m[j]=0;
                        objs.vel[k].x += objs.vel[j].x;
                        objs.vel[k].y += objs.vel[j].y;
                        objs.vel[k].z += objs.vel[j].z;
                        objs.flag[j] = 0; //we change the flag of the object
                    }
                }
            }
        }
    }
}
#endif //PROJECT1_FN_SOA_HPP