#include <iostream>
#include<fstream>
#include<random>
#include<cmath>
#include<vector>
#include <iomanip>
#include "fn-soa.hpp"


int main(int argc, char *argv[]) {
    // status stands for checking status
    std::cout <<"sim-soa invoked with "<<argc-1<<" parameters\n";
    std::cout << "Arguments:\n";
    // first we must check if the number of parameters read is exactly 6
    if(argc != 6){
        // if the number of parameters is incorrect we return -1
        if(argc == 1){
            std::cout<<"\tnum_objects: ?\n";
            std::cout<<"\tnum_iterations: ?\n";
            std::cout<<"\tseed: ?\n";
            std::cout<<"\tsize_enclosure: ?\n";
            std::cout<<"\ttime_step: ?\n";
        }
        else if(argc == 2)
        {
            std::cout<<"\tnum_objects: "<<argv[1]<<"\n";
            std::cout<<"\tnum_iterations: ?\n";
            std::cout<<"\tseed: ?\n";
            std::cout<<"\tsize_enclosure: ?\n";
            std::cout<<"\ttime_step: ?\n";
        }
        else if(argc == 3)
        {
            std::cout<<"\tnum_objects: "<<argv[1]<<"\n";
            std::cout<<"\tnum_iterations: "<<argv[2]<<"\n";
            std::cout<<"\tseed: ?\n";
            std::cout<<"\tsize_enclosure: ?\n";
            std::cout<<"\ttime_step: ?\n";
        }
        else if(argc == 4)
        {
            std::cout<<"\tnum_objects: "<<argv[1]<<"\n";
            std::cout<<"\tnum_iterations: "<<argv[2]<<"\n";
            std::cout<<"\tseed: "<<argv[3]<<"\n";
            std::cout<<"\tsize_enclosure: ?\n";
            std::cout<<"\ttime_step: ?\n";
        }
        else if(argc == 5)
        {
            std::cout<<"\tnum_objects: "<<argv[1]<<"\n";
            std::cout<<"\tnum_iterations: "<<argv[2]<<"\n";
            std::cout<<"\tseed: "<<argv[3]<<"\n";
            std::cout<<"\tsize_enclosure: "<<argv[4]<<"\n";
            std::cout<<"\ttime_step: ?\n";
        }
        else
        {
            std::cout<<"\tnum_objects: "<<argv[1]<<"\n";
            std::cout<<"\tnum_iterations: "<<argv[2]<<"\n";
            std::cout<<"\tseed: "<<argv[3]<<"\n";
            std::cout<<"\tsize_enclosure: "<<argv[4]<<"\n";
            std::cout<<"\ttime_step: "<<argv[5]<<"\n";
        }
        return -1;
    }

    //we get the parameters
    char *end1, *end2, *end3, *end4, *end5;
    double size_enclosure, time_step;
    long int num_objects, num_iterations, seed;
    num_objects= strtol(reinterpret_cast<const char *>(argv[1]), &end1, 10);
    num_iterations = strtol(reinterpret_cast<const char *>(argv[2]), &end2, 10);
    seed = strtol(reinterpret_cast<const char *>(argv[3]), &end3, 10);
    size_enclosure = strtof(reinterpret_cast<const char *>(argv[4]), &end4);
    time_step = strtof(reinterpret_cast<const char *>(argv[5]), &end5);

    // once the number of parameters is correct, we must check whether they have legal values or not
    if ((*end1 != '\0')||(*end2 != '\0')||(*end3 != '\0')||(*end4 != 0) ||(*end5 != 0 )) {
        // if one parameter is not an integer, we return -2
        std::cout<<"\tnum_objects: "<<argv[1]<<"\n";
        std::cout<<"\tnum_iterations: "<<argv[2]<<"\n";
        std::cout<<"\tseed: "<<argv[3]<<"\n";
        std::cout<<"\tsize_enclosure: "<<argv[4]<<"\n";
        std::cout<<"\ttime_step: "<<argv[5]<<"\n";
        return -2;
    }
    // now we must check if they are non-negative
    if((num_objects < 0)||(num_iterations<0)||(seed <= 0)||(size_enclosure < 0)||(time_step < 0)){
        // if one of them has an illegal value, we return -2
        std::cout<<"\tnum_objects: "<<argv[1]<<"\n";
        std::cout<<"\tnum_iterations: "<<argv[2]<<"\n";
        std::cout<<"\tseed: "<<argv[3]<<"\n";
        std::cout<<"\tsize_enclosure: "<<argv[4]<<"\n";
        std::cout<<"\ttime_step: "<<argv[5]<<"\n";
        return -2;
    }
    //now we must create the random initial positions, we create as many positions as number of objects
    Objects objs;
    //Objects objs{};
    //auto *objs= new Objects{};
    //Objects* objs{};
    // now we compute the random values using the mersenne twister, and the appropriate distributions
    std::mt19937_64 generator(seed);
    std::uniform_real_distribution<> dis(0, size_enclosure);
    std::normal_distribution<> d{1e21, 1e15};
    vect pos1{}, vel{};
    vel.x = 0.000;
    vel.y = 0.000;
    vel.z = 0.000;
    for (int i = 0; i < num_objects; ++i) {
        // we generate the random coordinates and mass for each object
        pos1.x = dis(generator);
        pos1.y = dis(generator);
        pos1.z = dis(generator);
        objs.pos.push_back(pos1);
        objs.vel.push_back(vel);
        objs.m.push_back(d(generator));
        objs.flag.push_back(1);
    }

    // we need tp check for collisions
    for(int i = 0; i < num_objects; ++i){
        for(int j = i; j < num_objects; ++j){
            if( j!=i){
                if(distance(objs.pos[i].x , objs.pos[i].y,  objs.pos[i].z, objs.pos[j].x, objs.pos[j].y, objs.pos[j].z) < 1){
                    objs.m[i] += objs.m[j];
                    // now we raise the flag of the object that disappears
                    objs.flag[j] = 0;

                }
            }
        }
    }

    // write information into the file
    std::ofstream out("init_config.txt");
    out<<std::fixed;
    out<<std::setprecision(3);
    // first we write the header line
    out << size_enclosure << " " << time_step << " " << num_objects << "\n";
    //now we write the info of each object
    for(int i = 0; i < num_objects; ++i){
        if(objs.flag[i]){
            out << objs.pos[i].x << " " << objs.pos[i].y << " " << objs.pos[i].z << " " << 0.000 << " " << 0.000 << " " << 0.000 <<" " <<objs.m[i] << "\n";
        }
    }
    out.close();


    //we declare the vectors we are going to use to store the forces
    vect **Forces;
    Forces= new vect *[num_objects];
    for (int i=0; i<num_objects;i++) Forces[i]= new vect[num_objects];

    // then comes the simulation part
    for(int i = 0; i < num_iterations; ++i){

        //gravitation
        grav_it(objs, Forces, num_objects, time_step, size_enclosure);
        std::cout<<"Position from main: "<<objs.pos[0].x<<std::endl;
        //Test:
        /*
        std::cout<<std::endl<<"Mass:";
        for (int i=0; i<num_objects; i++){
            std::cout<<"Obj: "<<objs[i].m<<" ";
        }
        std::cout<<std::endl<<"Coordinates";
        for (int i=0; i<num_objects; i++){
            std::cout<<"{"<<objs[i].pos.x<<" , "<<objs[i].pos.y<<" , "<<objs[i].pos.z<<"} " ;
        }

        std::cout<<std::endl<<"Test of values after grav_it: "<<std::endl;
        for (int i=0; i<num_objects;i++){
            for (int j=0; j<num_objects;j++) {
                std::cout<<"{"<<Forces[i][j].x<<" , "<<Forces[i][j].y<<" , "<<Forces[i][j].z<<"} " ;
            }
            std::cout<<std::endl;
        }
         */
        //acceleration
        //velocity
        //position
        //pos_and_bound_it(&objs, num_objects, time_step, size_enclosure);
        //bound
        //collision check
        for(int k = 0; k < num_objects; ++k){
            for(int j = k; j < num_objects; ++j ){
                if(j != k){
                    // poner if(distance(i,j) < 1 sumar masas velocidades y cambiar flags
                    if (distance(objs.pos[i].x , objs.pos[i].y,  objs.pos[i].z, objs.pos[j].x, objs.pos[j].y, objs.pos[j].z) < 1){
                        // if there are collisions at the beginning we must merge the two objects into one
                        objs.m[k] += objs.m[j];     // masses must be added
                        objs.vel[k].x += objs.vel[j].x;
                        objs.vel[k].y += objs.vel[j].y;
                        objs.vel[k].z += objs.vel[j].z;
                        objs.flag[j] = 0; //we change the flag of the object
                    }
                }
            }
        }


        //we write the info os the final configuration onto the file
        std::ofstream final("final_config.txt");
        final<<std::fixed;
        final<<std::setprecision(3);
        final << size_enclosure << " " << time_step << " " << num_objects << "\n";

        for(int i = 0; i < num_objects; ++i){
            if(objs.flag[i]){
                out << objs.pos[i].x << " " << objs.pos[i].y << " " << objs.pos[i].z << " " << objs.vel[i].x << " " << objs.vel[i].y<< " " << objs.vel[i].z<< " " << objs.m[i] << "\n";
            }
        }
        final.close();

        return 0;
    }
}
